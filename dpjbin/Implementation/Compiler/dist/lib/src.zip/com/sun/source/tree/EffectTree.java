package com.sun.source.tree;

public interface EffectTree extends Tree {

}

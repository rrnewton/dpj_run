package com.sun.source.tree;

public interface RPLTree extends Tree {

}

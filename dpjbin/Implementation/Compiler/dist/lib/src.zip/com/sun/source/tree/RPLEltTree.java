package com.sun.source.tree;

public interface RPLEltTree extends Tree {

}
